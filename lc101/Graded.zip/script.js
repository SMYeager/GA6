
	window.addEventListener("load", function() {

	fetch("https://handlers.education.launchcode.org/static/planets.json").then(function(response){
		          response.json().then(function(json) {
                  const div = document.getElementById("missionTarget");
                  // Add HTML that includes the JSON data
					let index = Math.floor(Math.random()*json.length);
				  
                  div.innerHTML = `
                     <h2>Mission Destination</h2>
						<ol>
						<li>Name: ${json[index].name}</li>
						<li>Diameter: ${json[index].diameter}</li>
						<li>Star: ${json[index].star}</li>
						<li>Distance from Earth: ${json[index].distance}</li>
						<li>Number of Moons: ${json[index].moons}</li>
						</ol>
						<img src="${json[index].image}">
                  `;
               });
            });
         
         	let form = document.querySelector("form");
			 
         	form.addEventListener("submit", function(event) {
				 event.preventDefault();

				let pilotName = document.querySelector("input[name=pilotName]");
				let fuelLevel = document.querySelector("input[name=fuelLevel]");
				let cargoMass = document.querySelector("input[name=cargoMass]");
         		let copilotName = document.querySelector("input[name=copilotName]");

				 let arrOfChecklist = [pilotName,copilotName,fuelLevel,cargoMass];

				 if (pilotName.value === "" || copilotName.value === "" ||fuelLevel.value === ""|| cargoMass.value === "") 
				 	{
            				alert("All fields are required!");
					}
				if (typeof (pilotName.value) !== "string" || typeof(copilotName.value) !== "string" ) 
            		{
            				alert("Names must consist of characters and spaces.");
					}

				
				let pilotTemp = `Pilot ${pilotName.value} Ready`;
				let copilotTemp = `Co-pilot ${copilotName.value} Ready`;
				let notEnoughFuel = `There is not enough fuel for the journey`;
				let tooMuchCargo = `There is too much cargo for the journey`;



				document.getElementById('faultyItems').style.visibility = 'visible';
				document.getElementById('pilotStatus').innerText = pilotTemp;
				document.getElementById('copilotStatus').innerText = copilotTemp;

				let fuel = false;
				let cargo = false;

				document.getElementById('launchStatus').innerText = "Awaiting More Information";
				document.getElementById('launchStatus').style.color = 'gray';
				document.getElementById('fuelStatus').innerText = 'Fuel level high enough for launch';
				document.getElementById('cargoStatus').innerText = 'Cargo mass low enough for launch';


 				if(!(isNaN(fuelLevel.value))){
					 if(fuelLevel.value < 10000){
							document.getElementById('fuelStatus').innerText = notEnoughFuel;
							document.getElementById('launchStatus').innerText = "Shuttle not ready for launch";
							document.getElementById('launchStatus').style.color = 'red';
					
						}
						else{
							fuel = true;
						}
				 }else{
						 alert("Fuel and/or Cargo must be in number format");
				 }

				 if(!(isNaN(cargoMass.value))){
						if(cargoMass.value > 10000){
							document.getElementById('launchStatus').innerText = "Shuttle not ready for launch";
							document.getElementById('cargoStatus').innerText = tooMuchCargo;							
							document.getElementById('launchStatus').style.color = 'red';
						 }
						 else{
							 cargo = true;
						 }
				 }else{
					 	 alert("Fuel and/or Cargo must be in number format");
				 }
				 
					if(fuel && cargo){
						document.getElementById('launchStatus').innerText = "Shuttle ready for launch!";
						document.getElementById('launchStatus').style.color = 'green';
						document.getElementById('fuelStatus').innerText = 'Fuel Cleared';
						document.getElementById('cargoStatus').innerText = 'Cargo Cleared';
					}
				 
				

      		});
		});



/* This block of code shows how to format the HTML once you fetch some planetary JSON!
<h2>Mission Destination</h2>
<ol>
   <li>Name: ${}</li>
   <li>Diameter: ${}</li>
   <li>Star: ${}</li>
   <li>Distance from Earth: ${}</li>
   <li>Number of Moons: ${}</li>
</ol>
<img src="${}">
*/